clc;
f = imread('contrast.tif');
[r,c,d] = size(f);
prompt = 'New minimum intensity:';
newMin = input(prompt);
prompt = 'New maximum intensity:';
newMax = input(prompt);
figure(1);
imshow(f);title('Original Image');
a = min(f(:));
b = max(f(:)); 
for i = 1:r
    for j = 1:c
        f(i,j)= (f(i,j)-a)*((newMax-newMin)/(b-a));
    end
end
figure(2);
imshow(f);title('Contrast Streached Image');