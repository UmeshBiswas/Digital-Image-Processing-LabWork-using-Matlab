clc;
im = imread('intensity Level.tif');
[r,c] = size(im);
prompt = 'Minimum intensity:';
threshold1 = input(prompt);
prompt = 'Maximum intensity:';
threshold2 = input(prompt);
prompt = 'Desired intensity:';
desired = input(prompt);
for i = 1:r
    for j = 1:c
        if(im(i,j,:) >= threshold1 && im(i,j,:) <= threshold2)
            im(i,j,:) = desired;
        else 
            im(i,j,:) = 0;
        end
    end
end
imshow(im);