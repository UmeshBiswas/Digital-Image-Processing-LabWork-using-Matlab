clc;
a = imread ('f1.tif');
%negative
neg(:,:,:) = 255 - a(:,:,:);
subplot(3,2,1);
imshow(neg);title('Negative');

%negative Built in
com = imcomplement(a);
subplot(3,2,2);
imshow(com);title('Negative 2');
imwrite(neg,'E:\neg.jpg','jpg');
imwrite(com,'E:\neg2.jpg','jpg');

%log
b = imread('f2.tif');
c = im2double(b);
bl = 2*log(1+c);
subplot(3,2,3);
imshow(bl);title('Log');
imwrite(bl,'E:\log.jpg','jpg');

%inverse log
e = imread('f2.tif');
f = im2double(e);
blin = 2*logninv(1+f);
subplot(3,2,4);
imshow(blin);title('inverse Log');
imwrite(blin,'E:\log2.jpg','jpg');

%power law
g = imread('f3.tif');
h = im2double(g);
po(:,:,:) = 1*power(h(:,:,:),4);
subplot(3,2,5);
imshow(po);title('Power');
imwrite(po,'E:\power.jpg','jpg');

%imadjust
i = imread('f3.tif');
j = imadjust(i,[0 1],[0 1],4);
subplot(3,2,6);
imshow(j);title('Power2');
imwrite(j,'E:\power2.jpg','jpg');

